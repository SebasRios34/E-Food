


export const precios = {
    pequenio: 1100,
    mediano: 1350,
    grande:1520
}


export const arrProductos = [
    {
        id: 1,
        nombreProducto: "combo#1",
        contenido: "papas medianas, sandwich de pollo, tocineta, tomate y queso"+
        " refresco mediano",
        enCarrito: false,
        cant:0,
        count:0,
        price:1350,
        total:0
    },
    {
        id: 2,
        nombreProducto: "combo#2",
        contenido: "triple quesoburguesa con tocineta y queso suizo",
        enCarrito: false,
        cant:0,
        count:0,
        price:7,
        total:0
    },{
        id: 3,
        nombreProducto: "combo#3",
        contenido: "wrap de pollo bien saludable para los chicos fit, con queso parmesano"+
        " y bebida cero calorias endulzada con splenda",
        enCarrito: false,
        cant:0,
        count:0,
        price:1520,
        total:0
    }


]

export const detalleProducto = {
    id: 1,
        nombreProducto: "combo#1",
        contenido: "papas medianas, sandwich de pollo, tocineta, tomate y queso"+
        " refresco mediano",
        enCarrito: false,
        cant:0,
        count:0,
        price:1100,
        total:0
}


