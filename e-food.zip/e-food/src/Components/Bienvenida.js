import React, { Component} from 'react';

//en el boton del carrito, la idea es que el boton sea un icono
//eso se tiene que hacer con el CSS pero por mientras esta sin formato
class Bienvenida extends Component {
    render (){
        return(
            
            <div>hola bienvenida</div>
          
        )
    }
}

export default Bienvenida;