import React, { Component } from 'react'

export default class Checkout extends Component {
    render() {
        return (
            <div>
                aqui va a ir el form para pagar
            </div>
        )
    }
}
